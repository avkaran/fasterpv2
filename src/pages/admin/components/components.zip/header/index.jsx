import React, { useContext } from 'react';
import { useHistory } from 'react-router-dom';
import { Spinner } from 'react-bootstrap';

import PsContext from '../../../../context';
import { currentRoutes } from '../../../../utils';
import { Logout } from '..';

const Header = (props) => {

	const context = useContext(PsContext);
	const history = useHistory();

	
	const getTitle = () => {
		var f = currentRoutes.filter(item => !item.divider && item.path.indexOf(history.location.pathname) > -1);

		return f && f.length > 0 ? f[0]['title'] : '';
	};



	const showNavbar = () => {
		//showNavbar('','','','');

		let nav = document.getElementById("nav-bar");
		let bodypd = document.getElementById("body-pd");
		let headerpd = document.getElementById("header");

		// Validate that all variables exist
		if (nav && bodypd && headerpd) {
			// show navbar
			nav.classList.toggle('nav_show');
			// change icon
			//toggle.classList.toggle('bx-x');
			// add padding to body
			bodypd.classList.toggle('body-pd');
			// add padding to header
			headerpd.classList.toggle('body-pd');
		}

		if (props.setCollapsed) props.setCollapsed();
	}


	return (
		<>


			<header className="header" id="header">
				<button className="header_toggle btn" onClick={e => showNavbar()} >
					<i className='bx bx-menu' id="header-toggle"></i>
				</button>
				<a className="ms-2 text-dark cmp_title" href="!#">
					{getTitle()}
				</a>
				<div className="ms-auto">
					{context.backgroundProcess && (<a className='pe-2 text-danger' href="!#">
						<Spinner animation="border" role="status" size="sm" />
						<span className='ps-2'>Running in background..</span>
					</a>)}
					<a className='font-weight-600' href="!#">
						{context.adminUser(props.match.params.userId).employee_name}
						{/*<span className='font-12 ms-2'>({capitalizeFirst(context.adminUser(props.match.params.userId).deptype)})</span>*/}
					</a>


					<Logout header />


					{/*<div className="header_img "> <img src="https://i.imgur.com/hczKIze.jpg" alt="" /> </div>

					<NavDropdown title="Dropdown" id="basic-nav-dropdown">
						<NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
						<NavDropdown.Item href="#action/3.2">Another action</NavDropdown.Item>
						<NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
						<NavDropdown.Divider />
						<NavDropdown.Item href="#action/3.4">Separated link</NavDropdown.Item>
					</NavDropdown>
					*/}
				</div>
			</header>

		</>
	);
};

export default Header;