import React from 'react';
import { NavLink } from 'react-router-dom';
import { Layout, Menu } from 'antd';
import { LOGO } from '../../../../utils/data';
import { currentInstance,currentNav } from '../../../../utils';
import { businesses } from '../../../../utils';
const { Sider } = Layout;
const { SubMenu } = Menu;

const Sidebar = (props) =>{
	const subMenu=(item, i)=>{
		return item.divider ?
		<a className="nav_link  nav_divider" href="!#"> </a>
		: item.allowed.indexOf(props.role)>-1 ? <Menu.Item key={i} icon={<i className={item.icon}></i>} title={item.name}>
			<NavLink to={item.path} >{item.name}</NavLink>
		</Menu.Item> : null;
	};

	const getNav=(item, i)=>{
		return item.divider ?
		<a className="nav_link  nav_divider" href="!#"> </a>
		: item.childrens && item.childrens.length>0 && item.allowed.indexOf(props.role)>-1 ? <SubMenu key={i} icon={<i className={item.icon}></i>} title={item.name}>
			{item.childrens.map((sm, j) => subMenu(sm, i+'_'+j))}
		</SubMenu>		
		: item.allowed.indexOf(props.role)>-1 ? <Menu.Item key={i} icon={<i className={item.icon}></i>} title={item.name}>
			<NavLink to={item.path} >{item.name}</NavLink>
		</Menu.Item> : null;
	}
  
		return(
			<>
	

			<div className="l-navbar" id="nav-bar">
				<a className="nav_logo" href="!#"> 
				
					<img src={LOGO} className='nav_logo-icon' alt="" style={{width: '23px'}} />
					<span className="nav_logo-name">{businesses[currentInstance.index].shortName}</span> </a>

					<div className='side_nav'>

						<Sider trigger={null} collapsible collapsed={props.collapsed} >
							<div className="logo" />
							<Menu theme="dark" defaultSelectedKeys={['1']} mode="inline">
								
								{currentNav.map((item, i) => getNav(item, i))}
							</Menu>
						</Sider>

					</div>
					
    			</div>
				
			</>
		);
};

export default Sidebar;