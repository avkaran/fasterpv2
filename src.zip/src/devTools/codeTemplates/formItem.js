export const FormItemTemplate = `
<FormItem
    label="{label}"
    name={name}
    {inputRules}
>
    {inputTemplate}
</FormItem>
`;