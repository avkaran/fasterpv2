const tl= {
  el: {
	topheader:{
		loginText: 'உள்நுழை',
		registerFree: 'இலவசமாக பதிவு செய்யுங்கள்',
		languageText: 'மொழி',
	},
    colorpicker: {
      confirm: 'சரி',
      clear: 'அழி'
    },
	login:{
		username: 'பயனர்பெயர்',
		password: 'கடவுச்சொல்',
		forgotPassword: 'கடவுச்சொல்லை மறந்துவிட்டீர்களா',
		buttonText: 'உள்நுழை',
	},
	register: {
		registerFree: 'இலவசமாக பதிவு செய்யுங்கள்',
	},
	matrimony:{
		bride: 'மணப்பெண்',
		groom: 'மணமகன்',
		religion: 'மதம்',
		caste: 'சாதி',
		searchText: 'தேடு',
	},
  }
};
export default tl;
