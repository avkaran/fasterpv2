import { FormItemTemplate } from './formItem';
import { FormTemplate } from './form';
import { AddEditModuleTemplate } from './addEditModule';
import {viewModuleTemplate} from './viewModule'
export{
	//AvatarList,
	FormItemTemplate,
	FormTemplate,
	AddEditModuleTemplate,
	viewModuleTemplate,
	
}