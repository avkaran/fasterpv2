const en= {
  el: {
	  topheader:{
		loginText: 'Login',
		registerFree: 'Free Registration',
		languageText: 'Language',
	},
    colorpicker: {
      confirm: 'OK',
      clear: 'Clear'
    },
	login:{
		username: 'Username',
		password: 'Password',
		forgotPassword: 'Forgot Password',
		buttonText: 'Login',
	},
	register: {
		registerFree: 'Register Free',
	},
	matrimony:{
		bride: 'Bride',
		groom: 'Groom',
		religion: 'Religion',
		caste: 'Caste',
		searchText: 'Search',
	},
  }
};
export default en;
