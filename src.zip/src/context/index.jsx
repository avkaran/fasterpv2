import React from 'react';

// first we will make a new context
const PsContext = React.createContext();

export default PsContext;
